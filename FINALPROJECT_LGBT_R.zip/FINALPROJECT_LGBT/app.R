

library(shiny)
library(dplyr)
library(geojsonio)
library(leaflet)
library(ggplot2)
library(shinythemes)

LGBTDataset <- read.csv("LGBT_Survey.csv")

#Changement de classe pour les pourcentages.
LGBTDataset$percentage <- as.numeric(LGBTDataset$percentage)
LGBTDataset$question_code <- as.character(LGBTDataset$question_code)
LGBTDataset$subset <- as.character(LGBTDataset$subset)
LGBTDataset$CountryCode <- as.character(LGBTDataset$CountryCode)

LGBTDataset <- filter(LGBTDataset, CountryCode!="Average")

#Séparation des questions fermées.
QuestionMap <- c("e1", "e2", "f1_a", "f1_b")

########################### DATAFRAME POUR LA MAP ###################################

LGBTMap <- filter(LGBTDataset, question_code %in% QuestionMap)

QuestionMap <- unique(select(LGBTMap, question_label, question_code))
QuestionMap$question_label <- c("Avoiding holding hands in public with a same-sex partner","Avoiding certain places", "Physicall/Sexual attack or threats in the last 5 years", "Personnal harassment leading to annoyment or offence in the last 5 years")


LGBTMap %>% 
    mutate(helpCalc = case_when(answer=="No" ~ -percentage, answer=="Yes" ~ percentage, TRUE ~ 0)) %>%
    filter(answer != "I do not have a same-sex partner") -> LGBTMap 

########################### DATAFRAME POUR LA PIECHART #################################
                                                                                       #
LGBTPieChart <- group_by(LGBTMap, CountryCode, question_code, subset)                  #
                                                                                       #
########################################################################################

LGBTMap <- summarize(LGBTPieChart, scale = - round(sum(helpCalc)/(sum(percentage)),2))

########################### DATAFRAME POUR LE BARGRAPH DE QUESTIONS FERMEES ##################################

#Séparation des questions qui se ressemblent.
Overall_WhatHappened <- c("fb1_4", "fb2_4")
Overall_WhoPredator <- c("fb1_7", "fb2_7")
Overall_GenderPredator <- c("fb1_8", "fb2_8")
Overall_WhereHappened <- c("fb1_10", "fb2_10")
Overall_WhyNotReportPolice <- c("fb1_12", "fb2_12")

DFWhatHappened <- filter(LGBTDataset, question_code %in% Overall_WhatHappened)
DFWhatHappened$question_label <- "Harassment experience : what happened ?"
DFWhatHappened %>%
    group_by(question_label, subset, answer) %>%
    summarize(mean = floor(mean(percentage))) -> DFWhatHappened

DFWhereHappened <- filter(LGBTDataset, question_code %in% Overall_WhereHappened)
DFWhereHappened$question_label <- "Harassment experience : where did it happened ?"
DFWhereHappened %>%
    group_by(question_label, subset, answer) %>%
    summarize(mean = floor(mean(percentage))) ->DFWhereHappened

DFWhoPredator <- filter(LGBTDataset, question_code %in% Overall_WhoPredator)
DFWhoPredator$question_label <- "Harassment experience : who was the predator ?"
DFWhoPredator %>%
    group_by(question_label, subset, answer) %>%
    summarize(mean = floor(mean(percentage))) -> DFWhoPredator

DFWhyNotReportPolice <- filter(LGBTDataset, question_code %in% Overall_WhyNotReportPolice)
DFWhyNotReportPolice$question_label <- "Harassment experience : why not reported to police ?"
DFWhyNotReportPolice %>%
    group_by(question_label, subset, answer) %>%
    summarize(mean = floor(mean(percentage))) -> DFWhyNotReportPolice

DFGenderPredator <- filter(LGBTDataset, question_code %in% Overall_GenderPredator)
DFGenderPredator$question_label <- "Violence and Harassment experience : predator gender ?"
DFGenderPredator %>%
    group_by(question_label, subset, answer) %>%
    summarize(mean = floor(mean(percentage))) -> DFGenderPredator

DFOpenQuestions <- bind_rows(DFWhatHappened, DFWhereHappened, DFWhoPredator, DFWhyNotReportPolice, DFGenderPredator)

ui <- fluidPage(
    
    tags$head(
        tags$link(rel = "stylesheet", type = "text/css", href = "bootstrap.css"),
        tags$style(HTML("
      @import url('//fonts.googleapis.com/css?family=Lobster|Cabin:400,700');
      
      h1 {
        font-family: 'Lobster', cursive;
        font-weight: 550;
        line-height: 1.1;
        color: #fa8072;
      }
        body {background-color: #ffe4e1;}

    "))
    ),
    
    headerPanel("LGBT Community : Violence and Harassment in Europe"),
    br(),

    theme = shinytheme("journal"),
    
    sidebarLayout(
    
        sidebarPanel(
            h2("PARAMETERS", 
               style = "font-family: 'Lobster', cursive;
                        font-weight: 350; line-height: 1.1; 
                        color: #ffa500;",
               align = "center"
            ),
            br(),
            selectInput("ChoiceSubject", "Subject :", choices =  QuestionMap$question_label),
            selectInput("ChoiceSubset", "Group :", choices = unique(LGBTMap$subset)),
            selectInput("ChoiceCountry", "Country : ", choices = unique(LGBTMap$CountryCode)),
            selectInput("ChoiceOpenSubject", "Open subject :", choices = unique(DFOpenQuestions$question_label))
        ),
        mainPanel(
            
            h2("Distribution scale of LGBT feelings towards their daily life in Europe", 
               style = "font-family: 'Lobster', cursive;
                        font-weight: 350; line-height: 1.1; 
                        color: #fa8072;",
               align = "center"
                   ),
            leafletOutput("OurMap"),
            h4("Interpretation :", style = "font-family: 'Lobster', cursive;
               color: #ffa500;",align = "center"),
            p("  As we can see with the map, people who are LGBT in Eastern Europe feel less safe regarding their sexuality (for LGB people) or gender (transgender people).
              Opposite to them, LGBT coming from Northern Europe feel safer in their countries regarding the harassment or violences they can suffer from."),
            p("However, transgender people seem less tolerated in Europe than people with non heterosexual orientation, and are more likely exposed to harassment and violences."),
            h2("Survey results for a chosen country, subset and subject :", 
               style = "font-family: 'Lobster', cursive;
                        font-weight: 350; line-height: 1.1; 
                        color: #fa8072;",
               align = "center"
            ),
            plotOutput("OurPieChart"),
            h2("Distribution of European countries on the LGBT tolerance scale :", 
               style = "font-family: 'Lobster', cursive;
                        font-weight: 350; line-height: 1.1; 
                        color: #fa8072;",
               align = "center"
            ),
            plotOutput("OurHistogram"),
            h4("Interpretation :", style = "font-family: 'Lobster', cursive;
               color: #ffa500;",align = "center"),
            p("This histogram is a complement to the choropleth map. On both, a little difference is exposed beteween how the LGBT community is feeling and what they are actually victim of (harassment and violences)."),
            p("Bisexual men and women are generally safe when it comes to attacks, even though out bisexual women are more exposed to harassment because their sexuality can mixed with sexual fantasies. For LGBT women, a part of sexism is also involved in their unsafety.
              Bisexual men and women, if in a heterosexual relationship and event not out of the closet yet, are less targets of homophobia. However, their fear of avoiding holding hands and certains places is almost the same."),
            p("As said before, lesbians and bisexual women are also victims of mysoginy, and are more likely to get harassed for their sexuality.
              Even though it seems like gays and lesbians who answered the survey are not that victimized with harassment and violences, they stil fear certain places and act (like touching hands).
              Indeed, as homophobia is still existing in Europe (more in certain countries than other), the fear of being targeted is not disappearing, explaining the difference between the firt two questions, and th last ones."),
            p("However, as transidentity is less understood and tolerated, their feeling of non safety and the attacks they suffer from are on the same scale."),
            h2("Survey results for open questions :", 
               style = "font-family: 'Lobster', cursive;
                        font-weight: 350; line-height: 1.1; 
                        color: #fa8072;",
               align = "center"
            ),
            textOutput("RecallQuestion"),
            plotOutput("OpenQuestionBarGraph", width = "250%"),
            h4("Interpretation :", style = "font-family: 'Lobster', cursive;
               color: #ffa500;",align = "center"),
            p("When it comes to harassing LGBT people, we can see that predators are more male than female. Indeed, women are in general more tolerant than men regarding LGBT people."),
            p("In general, recurrent types of harassment towards them are name calling and ridiculing. Making jokes about a specific community is sometimes not considered as oppressive by people, that is why it is more frequent."),
            p("The predator(s) appear(s) to be anyone. They can be strangers, colleagues, or costumers. However, a lot of them seems to be a member of family. The family of the victim may not tolerate the fact that someone of their family is not heterosexual or cisgender (= not transgender), and are closer to them than strangers. As a result, it is more possible for them, if they are homophobic or transphobic, to oppress them."),
            p("Harassment should be reported to the police, but sometimes, the victims do not do it. The main reasons are because they think their attack is not serious enough, or that the police would not believe them.
            'Other reason' is also mentioned a lot, one of them may be because in some countries, LGBT people are bad seen, even by the police (the predator can also be someone from the police), and report their harassment may lead them to an even worse situation.")
        )
    )
)



server <- function(input, output) {
    
    output$OurMap <- renderLeaflet({
        
        Europe <- geojson_read("europe.geo.json",  what = "sp")
        Europe <- subset(Europe, is.element(Europe$name, unique(LGBTMap$CountryCode)))
        
        ChosenSubject <- as.character(QuestionMap[QuestionMap$question_label==input$ChoiceSubject, "question_code"])
        ChosenSubset <- input$ChoiceSubset
        
        LGBTMap<- filter(LGBTMap, question_code==ChosenSubject & subset==ChosenSubset)
        LGBTMap <- LGBTMap[order(match(LGBTMap$CountryCode, Europe$name)),]
        
        bins = c(-1, -0.7, -0.4, -0.1, 0.1, 0.4, 0.7, 1)
        
        palette <- colorBin("Spectral", domain = LGBTMap$scale, bins=bins)
        
        labels <- sprintf("<strong>%s</strong><br/> <strong>Scale</strong> : %g",
                          LGBTMap$CountryCode, LGBTMap$scale) %>% lapply(htmltools::HTML)
        leaflet() %>%
            addProviderTiles(providers$Stamen.Toner) %>%
            addPolygons( data = Europe,
                         weight = 2,
                         opacity = 1,
                         smoothFactor = 0.5,
                         color = "white",
                         dashArray = "3",
                         fillOpacity = 0.9,
                         fillColor = palette(LGBTMap$scale),
                         highlightOptions = highlightOptions(
                             weight = 5,
                             fillOpacity = 0.9,
                             color = "pink",
                             dashArray = "",
                             bringToFront = TRUE),
                         label = labels,
                         labelOptions = labelOptions(
                             style = list("font-weight" = "normal", padding = "3px 8px"),
                             textsize = "15px",
                             direction = "auto")) %>%
            addLegend(pal = palette, 
                      values = LGBTMap$scale, 
                      opacity = 0.8, 
                      title = "SCALE LEGEND",
                      position = "bottomleft")
    })
    
    output$OurPieChart <- renderPlot({
        
        ChosenSubject <- as.character(QuestionMap[QuestionMap$question_label==input$ChoiceSubject, "question_code"])
        ChosenSubset <- input$ChoiceSubset
        ChosenCountry <- input$ChoiceCountry
        
        LGBTPieChart <- filter(LGBTPieChart, CountryCode==ChosenCountry & question_code==ChosenSubject & subset==ChosenSubset)
        Normalisation <- 100/sum(LGBTPieChart$percentage)
        pct <- round(LGBTPieChart$percentage*Normalisation)
        lbls <- paste(LGBTPieChart$answer, pct)
        lbls <- paste(lbls, "%", sep = "")
        Normalisation <- 100/sum(LGBTPieChart$percentage)
        pie(LGBTPieChart$percentage, labels = lbls)
    })
    
    output$OurHistogram <- renderPlot({
        
        ChosenSubject <- as.character(QuestionMap[QuestionMap$question_label==input$ChoiceSubject, "question_code"])
        ChosenSubset <- input$ChoiceSubset
        
        LGBTMap <- filter(LGBTMap, question_code==ChosenSubject & subset==ChosenSubset)
        
        ggplot(data = LGBTMap, aes(x=LGBTMap$scale)) +
            geom_histogram( binwidth=0.1, alpha=0.9) +
            labs(x = "Scale", y = "Number of European country") +
            theme(plot.title = element_text(size=15, hjust = 0.5))
    })
    
    output$RecallQuestion <- renderText({
        paste(input$ChoiceSubset, " -> ", input$ChoiceOpenSubject) 
    })
    
    output$OpenQuestionBarGraph <- renderPlot({
        
        ChosenOpenSubject <- input$ChoiceOpenSubject
        ChosenSubset <- input$ChoiceSubset
        
        DFOpenQuestions <- filter(DFOpenQuestions, question_label==ChosenOpenSubject & subset==ChosenSubset)
        
        ggplot(data=DFOpenQuestions, aes_string(x=DFOpenQuestions$answer,y=DFOpenQuestions$mean, label = DFOpenQuestions$answer))  + 
            geom_bar(stat="identity",width = 0.5) + 
            labs(x = "Answers", y = "Number of answers") + 
            theme(plot.title = element_text(size = 15, hjust = 0.5)) 
    })
    
    
}

shinyApp(ui = ui, server = server)
